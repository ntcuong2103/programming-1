#include <assert.h>

int factorial(int N)
{
    if (N == 0) return 1;
    if (N == 1) return 1;

    if (N > 1) return N * factorial(N - 1);
}

int factorial_loop(int N)
{
    if (N == 0) return 1;

    int ret = 1;
    for (int i = 1; i <= N; i++)
    {
        ret *= i;
    }
    return ret;
}

int factorial_rev_loop(int N)
{
    if (N == 0) return 1;

    int ret = 1;
    for (int i = N; i >= 1; i--)
    {
        ret *= i;
    }
    return ret;
}

int main()
{
    int N = 10;
    int ans = factorial(N);

    assert(factorial(N) == factorial_loop(N));
    assert(factorial(N) == factorial_rev_loop(N));
    
    return 0; // set break point here to check result
}