#include <math.h>
#include <stdlib.h>

int calculate(char *s[], int N)
{
    int ans = atoi(s[0]);
    char last_op;
    for (int i = 1; i < N; i++)
    {
        if (i % 2 == 1)
        {
            last_op = s[i][0];
        }
        else
        {
            int right_operant = atoi(s[i]);
            switch (last_op)
            {
            case '+':
                ans += right_operant;
                break;
            case '-':
                ans -= right_operant;
                break;
            case '*':
                ans *= right_operant;
                break;
            case '/':
                ans = (int)floor((float)ans / right_operant);
                break;
            default:
                break;
            }
        }
    }

    return ans;
}

/**
 * Implementation of itoa function: convert an integer to string (char*)
*/
char * itoa(int value)
{
    char *buffer = malloc(30 * sizeof (char));
    sprintf(buffer, "%d", value);
    return buffer;
}

/**
 * Calculator with operator order
 * Simple version of 
 * https://leetcode.com/problems/basic-calculator-ii/
*/
int calculate_with_operator_order(char *s[], int N)
{
    char *s_processed[N]; // array to store the intermediate results

    int start = 0;
    int index_of_processed = 0;
    // split by '+' and '-' operator
    for (int i = 1; i < N-1; i+=2)
    {
        if (s[i][0] == '+' || s[i][0] == '-')
        {
            s_processed[index_of_processed++] = itoa(calculate(&(s[start]), (i - 1) - start + 1));
            s_processed[index_of_processed++] = s[i];
            start = i+1;
        }
    }

    // last splited expression
    s_processed[index_of_processed] = itoa(calculate(&(s[start]), (N - 1) - start + 1));

    return calculate(s_processed, index_of_processed + 1);
}

/**
 * https://leetcode.com/problems/clumsy-factorial/
*/
int clumsy_factorial(int N)
{
    char *op[4] = {"*", "/", "+", "-"};

    // create a math expression of 
    // {"10", "*", "9", "/", "8", "+", "7", "-", "6", "*", "5", "/", "4", "+", "3", "-", "2", "*", "1"} 
    char *expression[2*N - 1]; 

    int index = 0;
    int op_index = 0;
    for (int num = N; num >= 1; num--)
    {
        expression[index++] = itoa(num);
        if (index == 2*N - 1) break;
        expression[index++] = op[(op_index++) % 4];
    }

    return calculate_with_operator_order(expression, 2*N - 1);
}

int main()
{
    char *s[9] = {"25", "+", "3", "/", "10", "+", "12", "*", "3"};
    int ans = calculate_with_operator_order(s, 1);
    int factorial = clumsy_factorial(10);
    return 0;
}