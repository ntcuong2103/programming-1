#include <math.h>

int *toBinary(int n, int *returnSize)
{
    int size = (int)floor(log2(n)) + 1; // Note: n > 0 as in leetcode description
    int *out = malloc(size * sizeof(int));
    *returnSize = size;
    int i = 0;
    do
    {
        out[i++] = n % 2;
        n /= 2;
    } while (n > 0);

    return out;
}

/**
 * https://leetcode.com/problems/number-of-even-and-odd-bits/
 *
 * Note: The returned array must be malloced, assume caller calls free().
 */
int *evenOddBit(int n, int *returnSize)
{
    int *out = malloc(2 * sizeof(int));
    *returnSize = 2;
    int binSize;
    int *bin = toBinary(n, &binSize);

    out[0] = out[1] = 0;

    for (int i = 0; i < binSize; i++)
    {
        if (bin[i])
        {
            if (i % 2 == 0) // even
            {
                out[0] += 1;
            }
            else
            {
                out[1] += 1;
            }
        }
    }
    free(bin);
    return out;
}