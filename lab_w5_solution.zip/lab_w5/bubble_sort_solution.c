#include <stdio.h>

int swap_counter = 0;

// exchange values of the pointers
void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
    swap_counter++; 
}

void bubble_sort(int *arr, int N)
{
   if (N >= 2)
    {
        for (int i = 0 ; i < N - 1; i++)
        {
            if (arr[i] > arr[i+1])
            {
                swap(&(arr[i]), &arr[i+1]);
            }
        }
        
        bubble_sort(arr, N-1);
    }
}

int main()
{
    int arr[] = {1, 4, 3, 7, 6};
    bubble_sort(arr, 5);

    printf("num of swaps: %d\n", swap_counter);

    return 0; // set break point
}