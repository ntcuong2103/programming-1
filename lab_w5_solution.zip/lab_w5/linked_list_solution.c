#include <stdlib.h>

struct Node
{
    int data;
    struct Node* next;
};

// insert a node with data to the end of the list
// assume that head is not NULL
void push_back(struct Node* head, int data)
{
    struct Node* new = malloc(sizeof(struct Node));
    new->data = data;
    new->next = NULL;

    // trace to the end node
    struct Node* ptr = head;
    while (ptr->next != NULL)
    {
        ptr = ptr->next;
    }

    ptr->next = new;
}

struct Node* toLinkedList(int* data_arr, int N)
{
    struct Node* head = malloc(sizeof(struct Node));
    head->data = data_arr[0];
    head->next = NULL;

    for (int i = 1; i < N; i++)
    {
        push_back(head, data_arr[i]);
    }

    return head;
}

int* getData(struct Node* head, int* ret_size)
{
    int* out = NULL;
    int size = 0;

    struct Node* ptr = head;

    while (ptr != NULL)
    {
        size++;
        out = realloc(out, size * sizeof(int));
        out[size - 1] = ptr->data;
        ptr = ptr->next;
    }
    *ret_size = size;
    return out;
}

int main()
{
    int arr[] = { 1, 4, 3, 7, 6 };

    struct Node* linked_list = toLinkedList(arr, 5);

    int ret_size;
    int* out = getData(linked_list, &ret_size);

    for (int i = 0; i < ret_size; i++)
    {
        printf("%d, ", out[i]);
    }
    return 0; // set break point
}
