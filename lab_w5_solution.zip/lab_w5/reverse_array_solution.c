#include <stdlib.h>

// exchange values of the pointers
void swap(int* a, int* b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

// reverse array function
void reverse_array(int* arr, int N)
{
    int i, j;
    for (i = 0, j = N - 1; i < j; i++, j--)
    {
        swap(&(arr[i]), &(arr[j]));
    }
}

int main()
{
    int arr[] = {1, 4, 3, 7, 6};
    reverse_array(arr, 5);

    return 0; // set break point
}