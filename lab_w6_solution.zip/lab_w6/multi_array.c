#include <stdlib.h>
#include <time.h>
#include <stdio.h>

struct MultiArray
{
    int* data; // 1d array: flattened multi-array
    int* shape; // 1d array: shape of multi-array 
};

void deallocate_array(struct MultiArray* array)
{
    free(array->data);
    free(array->shape);
}

/**
 * Indexing multi array using an index array
 *
 * array [2][1] = get_data(array, [2, 1])
*/
// convert indexes to flat_index
int get_data(struct MultiArray* array, int* indexes, int n_dims)
{
    int flat_index = 0;
    int cumul_shape = 1;
    for (int i = n_dims - 1; i >= 0; i--)
    {
        flat_index += indexes[i] * cumul_shape;
        cumul_shape *= array->shape[i];
    }

    return array->data[flat_index];
}

void print_array(struct MultiArray* array, int n_dims)
{
    int* size_levels = malloc(n_dims * sizeof(int));

    int cumul_size = 1;
    for (int i = n_dims - 1; i >= 0; i--)
    {
        cumul_size *= array->shape[i];
        size_levels[i] = cumul_size;
    }

    for (int i = 0; i < cumul_size; i++)
    {
        for (int j = 0; j < n_dims; j++)
        {
            if (i % size_levels[j] == 0)
            {
                printf("[");
            }
        }
        printf("%d,", array->data[i]);

        for (int j = 0; j < n_dims; j++)
        {
            if (i % size_levels[j] == size_levels[j] - 1)
            {
                printf("]");
            }
        }
    }
    printf("\n");
    free(size_levels);
}

int main()
{
    // set random seed to current time
    srand(time(NULL));

    struct MultiArray* array = malloc(sizeof(struct MultiArray));

    // create 3x4 array
    array->data = malloc(3 * 2 * 2 * sizeof(int));

    // assign random data (0 -> 9)
    for (int i = 0; i < 3 * 2 * 2; i++)
    {
        array->data[i] = rand() % 10;
    }

    // assign shape
    array->shape = malloc(3 * sizeof(int));
    array->shape[0] = 3;
    array->shape[1] = 2;
    array->shape[2] = 2;

    print_array(array, 3);


    int indexes[] = { 1, 0, 1 };
    int out = get_data(array, indexes, 3);
    printf("array[%d][%d][%d] = %d\n", indexes[0], indexes[1], indexes[2], out);

    deallocate_array(array);
    free(array);

    return 0;
}

