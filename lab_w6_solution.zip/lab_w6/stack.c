#include <assert.h>
#include <stdlib.h>
#include <stdio.h>

/// @brief Implement stack using linked list

struct Node
{
    int data;
    struct Node* next;
};

struct Stack
{
    struct Node* top; // also be the head of the linked list
};

void push(struct Stack* stack, int data)
{
    // create new node
    struct Node* new_node = malloc(sizeof(struct Node));
    new_node->data = data;
    new_node->next = NULL;

    // insert to the head of linked list
    new_node->next = stack->top;

    // set top as the new node
    stack->top = new_node;
}

int pop(struct Stack* stack)
{
    assert(stack->top != NULL);

    // get top data
    struct Node* top = stack->top;
    int output = top->data;
    // move stack top 
    stack->top = top->next;

    // delete old top
    free(top);
    return output;
}

// return 1 if the stack is empty otherwise 0
int is_empty(const struct Stack* stack)
{
    return stack->top == NULL;
}

int main()
{
    struct Stack* stack = malloc(sizeof(struct Stack));
    stack->top = NULL;

    push(stack, 1);
    push(stack, 2);
    push(stack, 3);
    push(stack, 4);

    while (!is_empty(stack))
    {
        printf("%d\n", pop(stack));
    }

    free(stack);

    return 0;
}