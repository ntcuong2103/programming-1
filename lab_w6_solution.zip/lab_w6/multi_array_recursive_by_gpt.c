#include <stdio.h>
#include <stdlib.h>

// Recursive function to allocate an n-dimensional array
void* allocateNDArray(int numDimensions, int* dimensions, size_t elementSize) {
    if (numDimensions <= 0) {
        return NULL;
    }

    if (numDimensions == 1) {
        // Allocate memory for a 1D array
        return malloc(dimensions[0] * elementSize);
    }

    // Allocate memory for the current dimension and recursively for the sub-array
    void** array = malloc(dimensions[0] * sizeof(void*));
    for (int i = 0; i < dimensions[0]; i++) {
        array[i] = allocateNDArray(numDimensions - 1, dimensions + 1, elementSize);
    }

    return array;
}

// Function to deallocate the n-dimensional array
void deallocateNDArray(void* array, int* dimensions, int numDimensions) {
    if (array == NULL || numDimensions <= 0) {
        return;
    }

    if (numDimensions == 1) {
        free(array);
    }
    else {
        void** subArray = (void**)array;
        for (int i = 0; i < dimensions[0]; i++) {
            deallocateNDArray(subArray[i], dimensions + 1, numDimensions - 1);
        }
        free(subArray);
    }
}

int main() {
    int dimensions[] = { 2, 3, 4, 5 }; // Change this array to set the dimensions
    int numDimensions = sizeof(dimensions) / sizeof(dimensions[0]);
    size_t elementSize = sizeof(int); // Change this based on your array type

    int**** multiArray = (int****)allocateNDArray(numDimensions, dimensions, elementSize);

    // Access and manipulate the elements (e.g., multiArray[1][2][3][4])

    // Deallocate the memory
    deallocateNDArray(multiArray, dimensions, numDimensions);

    return 0;
}
