#include <stdio.h>
#include <stdlib.h>

/// @brief Example for 3-d array
/// @param shape: [3, 2, 2]
/// @param n_dims: 3
/// @param level: 2 --> first axis, 1 --> second axis, 0 --> last axis 
/// @return 
void* create_array(int* shape, int n_dims, int level)
{
    void* array;
    int dim = shape[n_dims - 1 - level];
    printf("create array %d dim at level %d\n", dim, level);

    if (level == 0)
    {
        array = malloc(dim * sizeof(int));
    }
    else
    {
        array = malloc(dim * sizeof(int*));
        for (int i = 0; i < dim; i++)
        {
            ((int**)array)[i] = (int*)create_array(shape, n_dims, level - 1);
        }
    }

    return array;
}

void delete_array(void* array, int* shape, int n_dims, int level)
{
    int dim = shape[n_dims - 1 - level];

    if (level == 0)
    {
        free(array);
    }
    else
    {
        for (int i = 0; i < dim; i++)
        {
            delete_array(((int**)array)[i], shape, n_dims, level - 1);
        }
        free(array);
    }
}

int main()
{
    int shape[] = { 2, 3, 4, 5 };

    int**** array_nd = (int****)create_array(shape, 4, 3);

    delete_array(array_nd, shape, 4, 3);

    return 0;
}