#include <time.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>

#include <stdlib.h>

int max(int a, int b)
{
    return a > b ? a : b;
}
int min(int a, int b)
{
    return a < b ? a : b;
}
int sum(int a, int b)
{
    return a + b;
}

/**
 * Write reduce function where func is one of "max", "min", "sum"
 * Return func(array)
*/
int reduce(int** arr, int N, int M, const char* func)
{
    assert(N > 0 && M > 0);

    int result;

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < M; j++)
        {
            if (i == 0 && j == 0)
            {
                result = arr[i][j];
            }
            else
            {
                if (strcmp(func, "max") == 0)
                {
                    result = max(result, arr[i][j]);
                }
                if (strcmp(func, "min") == 0)
                {
                    result = min(result, arr[i][j]);
                }
                if (strcmp(func, "sum") == 0)
                {
                    result = sum(result, arr[i][j]);
                }
            }
        }
    }

    return result;
}

/**
 * Write reduce function by axis where func is one of "max", "min", "sum"
 * The return value should be 1-dimensional array
 * Return func(array, axis)
*/
int* reduce_with_axis(int** arr, int N, int M, const char* func, int axis)
{
    assert(N > 0 && M > 0);

    int* out;

    // allocate 1d array
    if (axis == 1)
    {
        out = malloc(N * sizeof(int));
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < M; j++)
            {
                if (j == 0)
                {
                    out[i] = arr[i][j];
                }
                else
                {
                    if (strcmp(func, "max") == 0)
                    {
                        out[i] = max(out[i], arr[i][j]);
                    }
                    if (strcmp(func, "min") == 0)
                    {
                        out[i] = min(out[i], arr[i][j]);
                    }
                    if (strcmp(func, "sum") == 0)
                    {
                        out[i] = sum(out[i], arr[i][j]);
                    }
                }
            }
        }
    }
    else
    {
        out = malloc(M * sizeof(int));
        for (int j = 0; j < M; j++)
        {
            for (int i = 0; i < N; i++)
            {
                if (i == 0)
                {
                    out[j] = arr[i][j];
                }
                else
                {
                    if (strcmp(func, "max") == 0)
                    {
                        out[j] = max(out[j], arr[i][j]);
                    }
                    if (strcmp(func, "min") == 0)
                    {
                        out[j] = min(out[j], arr[i][j]);
                    }
                    if (strcmp(func, "sum") == 0)
                    {
                        out[j] = sum(out[j], arr[i][j]);
                    }
                }
            }
        }
    }

    // return the reduced array
    return out;
}


/**
 * Write transpose function to transpose NxM array -> MxN array
*/
int** transpose(int** two_array, int N, int M)
{
    // allocate MxN array
    int** transposed = malloc(M * sizeof(int*));
    for (int i = 0; i < M; i++)
    {
        transposed[i] = malloc(N * sizeof(int));
    }

    // transposed [i][j] = two_array [j][i]
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
        {
            transposed[i][j] = two_array[j][i];
        }
    }

    // return the transposed array
    return transposed;
}

void deallocate_2d_array(int** two_array, int N)
{
    for (int i = 0;i < N; i++)
    {
        free(two_array[i]);
    }
    free(two_array);
}

int main()
{
    // set random seed to current time
    srand(time(NULL));

    int N = 3, M = 4;
    // allocate NxM array
    int** two_array = malloc(N * sizeof(int*)); // allocate N x (int *)
    for (int i = 0; i < N; i++)
    {
        two_array[i] = malloc(M * sizeof(int)); // allocate M x (int)

        // set random value (0->9) for each element of array
        for (int j = 0; j < M; j++)
        {
            two_array[i][j] = rand() % 10;
            printf("array[%d][%d] = %d\n", i, j, two_array[i][j]);
        }
    }

    int reduced = reduce(two_array, N, M, "max");

    int* reduced_axis = reduce_with_axis(two_array, N, M, "max", 0);

    int** transposed_array = transpose(two_array, N, M);

    free(reduced_axis);
    deallocate_2d_array(two_array, N);
    deallocate_2d_array(transposed_array, M);

    return 0;
}