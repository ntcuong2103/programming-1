#include <stdbool.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/// @brief Implement stack using linked list

struct Node
{
    int data;
    struct Node* next;
};

struct Stack
{
    struct Node* top; // also be the head of the linked list
};

void push(struct Stack* stack, int data)
{
    // create new node
    struct Node* new_node = malloc(sizeof(struct Node));
    new_node->data = data;
    new_node->next = NULL;

    // insert to the head of linked list
    new_node->next = stack->top;

    // set top as the new node
    stack->top = new_node;
}

int pop(struct Stack* stack)
{
    assert(stack->top != NULL);

    // get top data
    struct Node* top = stack->top;
    int output = top->data;
    // move stack top 
    stack->top = top->next;

    // delete old top
    free(top);
    return output;
}

// return 1 if the stack is empty otherwise 0
int is_empty(const struct Stack* stack)
{
    return stack->top == NULL;
}

int reverse_bracket(char bracket)
{
    switch (bracket)
    {
    case '(':
        return ')';
    case '[':
        return ']';
    case '{':
        return '}';
    }
    return -1;
}

bool isValid(char* s)
{
    int len = strlen(s);

    struct Stack* charStack = malloc(sizeof(struct Stack));

    for (int i = 0; i < len; i++)
    {
        if (s[i] == '{' || s[i] == '[' || s[i] == '(')
        {
            push(charStack, s[i]);
        }
        else
        {
            if (is_empty(charStack)) return false;

            if (s[i] != reverse_bracket(pop(charStack)))
            {
                return false;
            }
        }
    }

    if (is_empty(charStack)) return true;
    else return false;
}

int main()
{
    bool ret = isValid("()[]}");
    return 0;
}
